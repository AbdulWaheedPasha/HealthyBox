<?php
class address_model
{
    // Properties
    public $program_id;
    // Methods
    function set_program_id($program_id)
    {
        $this->program_id = $program_id;
    }
    function get_program_id()
    {
        return $this->program_id;
    }

}

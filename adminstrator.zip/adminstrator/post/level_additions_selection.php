<?php
echo $_POST['value'];

?>
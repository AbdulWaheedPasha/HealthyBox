<?php 

echo 'print.php';

?>
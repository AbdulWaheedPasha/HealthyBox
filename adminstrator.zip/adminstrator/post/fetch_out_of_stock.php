<?php

echo "1";

?>
<?php
$con = @mysqli_connect('localhost', 'althybq7__user', '&tETKQ1U4MoK', 'althybq7_healthy_box');
if (!$con) {
    echo "Error: " . mysqli_connect_error();
	exit();
}
//echo 'Connected to MySQL';
?>